<?php
$conn = mysqli_connect("localhost", "root", "");
mysqli_query($conn, "CREATE DATABASE IF NOT EXISTS planets_db");
mysqli_select_db($conn, "planets_db");

mysqli_query($conn, "CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(100) UNIQUE,
  password VARCHAR(255)
)");

$hashed = password_hash("123456", PASSWORD_DEFAULT);
mysqli_query($conn, "INSERT IGNORE INTO users (email, password) VALUES ('faimah@example.com', '$hashed')");

echo "Database and users table created!";
?>
