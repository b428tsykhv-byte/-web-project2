<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include("conn.php");

/* ✅ إنشاء الجدول لو مو موجود */
mysqli_query($conn, "CREATE TABLE IF NOT EXISTS planets (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100),
  description TEXT
)");

$message = "";

/* ADD */
if (isset($_POST["add"])) {
  $name = trim($_POST["name"]);
  $description = trim($_POST["description"]);

  if ($name != "" && $description != "") {
    mysqli_query($conn, "INSERT INTO planets (name, description) VALUES ('$name', '$description')");
    $message = "Planet added";
  } else {
    $message = "Please fill in all fields";
  }
}

/* UPDATE */
if (isset($_POST["update"])) {
  $id = $_POST["id"];
  $name = trim($_POST["name"]);
  $description = trim($_POST["description"]);

  if ($name != "" && $description != "") {
    mysqli_query($conn, "UPDATE planets SET name='$name', description='$description' WHERE id=$id");
    $message = "Planet updated";
  } else {
    $message = "Please fill in all fields";
  }
}

/* DELETE */
if (isset($_GET["delete"])) {
  $id = $_GET["delete"];
  mysqli_query($conn, "DELETE FROM planets WHERE id=$id");
  $message = "Planet deleted";
}

/* EDIT */
$editPlanet = null;
if (isset($_GET["edit"])) {
  $id = $_GET["edit"];
  $editResult = mysqli_query($conn, "SELECT * FROM planets WHERE id=$id");
  $editPlanet = mysqli_fetch_assoc($editResult);
}

/* SELECT */
$result = mysqli_query($conn, "SELECT * FROM planets");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Planets CRUD</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>

<header>
  <img src="images/logo.png" class="logo">
</header>

<main>
  <h1>Planets CRUD (PHP + MySQL)</h1>

  <?php if ($message != "") echo "<p>$message</p>"; ?>

  <?php if ($editPlanet) { ?>
    <h2>Edit Planet</h2>
    <form method="POST">
      <input type="hidden" name="id" value="<?php echo $editPlanet['id']; ?>">

      <label>Planet Name</label>
      <input type="text" name="name" value="<?php echo $editPlanet['name']; ?>" required>

      <label>Description</label>
      <textarea name="description" required><?php echo $editPlanet['description']; ?></textarea>

      <button type="submit" name="update">Update</button>
    </form>
  <?php } else { ?>
    <h2>Add Planet</h2>
    <form method="POST">
      <label>Planet Name</label>
      <input type="text" name="name" required>

      <label>Description</label>
      <textarea name="description" required></textarea>

      <button type="submit" name="add">Add</button>
    </form>
  <?php } ?>

  <h2>All Planets</h2>

  <table border="1" cellpadding="8">
    <tr>
      <th>ID</th>
      <th>Name</th>
      <th>Description</th>
      <th>Actions</th>
    </tr>

    <?php while ($row = mysqli_fetch_assoc($result)) { ?>
      <tr>
        <td><?php echo $row['id']; ?></td>
        <td><?php echo $row['name']; ?></td>
        <td><?php echo $row['description']; ?></td>
        <td>
          <a href="?edit=<?php echo $row['id']; ?>">Edit</a> |
          <a href="?delete=<?php echo $row['id']; ?>">Delete</a>
        </td>
      </tr>
    <?php } ?>
  </table>
</main>

</body>
</html>
 