<?php
include("conn.php");

$result = mysqli_query($conn, "SELECT COUNT(*) AS total FROM planets");
$row = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html>
<head>
    <title>PHP Test</title>
</head>
<body>

<h2>PHP is working ✅</h2>
<p>Total planets in database: <?php echo $row['total']; ?></p>

<a href="index.html">Back to Home</a>

</body>
</html>